package xquery;

import java.io.IOException;

import javax.xml.xquery.XQException;

public interface prac {
	public void ej1() throws XQException;
	public void ej2(String var) throws XQException;
	public void ej3() throws IOException, XQException;


}
