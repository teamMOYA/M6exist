package xquery;

import java.util.Scanner;

public class main {

	public static void main(String[] args) throws Exception {
		prac practica = new pracIMP();

		System.out.println("ej1");
		practica.ej1();
		System.out.println("-------");

		System.out.println("ej2");
		Scanner sc = new Scanner(System.in);
		practica.ej2(sc.nextLine());
		System.out.println("-------");

		System.out.println("ej3");
		practica.ej3();


		// TODO Auto-generated method stub

	}



}

