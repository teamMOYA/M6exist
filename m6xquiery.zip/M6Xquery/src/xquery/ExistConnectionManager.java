package xquery;

import javax.xml.xquery.XQConnection;
import javax.xml.xquery.XQDataSource;
import javax.xml.xquery.XQException;

import net.xqj.exist.ExistXQDataSource;

public class ExistConnectionManager{
        private static final String IP = "localhost";
        private static final String PORT = "8080";
        private static final String USER = "admin";
        private static final String PASS = "admin";

        private static XQDataSource server;
        private static XQConnection connection = null;

        static{

                //INICIALIZAR
                server = new ExistXQDataSource();
                //VALORES
                try{
                	server.setProperty("serverName","localhost");
                	server.setProperty("port","8080");
                	server.setProperty("user","admin");
                	server.setProperty("password","admin");
                } catch (XQException e){
                	e.printStackTrace();
                }
        }

        private static void connect(){
        	try{
        		connection = server.getConnection();
        	} catch (XQException e){
        		e.printStackTrace();
        	}
        }

        public static XQConnection getConnection(){
                if (connection == null || connection.isClosed()){
                        connect();
                }
                return connection;
        }

        public static void closeConnection(){
		try{
                	connection.close();
		} catch (XQException e){
			e.printStackTrace();
		}
        }
}