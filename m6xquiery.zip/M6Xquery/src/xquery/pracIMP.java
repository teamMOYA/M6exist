package xquery;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import javax.xml.xquery.XQConnection;
import javax.xml.xquery.XQException;
import javax.xml.xquery.XQPreparedExpression;
import javax.xml.xquery.XQResultSequence;

public class pracIMP implements prac {

	private XQConnection connection;

	public void ej1() throws XQException{
		connection = ExistConnectionManager.getConnection();

		String squery = "for $producte in /productos/produc "
				+ "let $codi:=data($producte/cod_prod) "
				+ "let $denominacio:=data($producte/denominacion) "
				+ "let $preu:=data($producte/precio) "
				+ "let $nom_zona:=data(/zonas/zona/nombre[../cod_zona=$producte/cod_zona]) "
				+ "order by $nom_zona "
				+ "return concat($codi, ' ' , $denominacio, ' ', $preu, ' ', $nom_zona) ";

			XQPreparedExpression consulta = connection.prepareExpression(squery);
			XQResultSequence resultat = consulta.executeQuery();
			while(resultat.next()){
				System.out.println("Element:"  + resultat.getItemAsString(null));
			}

	}
	public void ej2(String var) throws XQException{
		connection = ExistConnectionManager.getConnection();

		String squery = "for $producte in /productos/produc[./stock_minimo < " +var + "] "
				+ "let $codi := data($producte/cod_prod)"
				+ "let $denominacio:=data($producte/denominacion) "
				+ "let $preu:=data($producte/precio) "
				+ "let $minstock:=data($producte/stock_minimo)"
				+ "return concat('cod: ', $codi, ' denom: ' , $denominacio, ' preu: ', $preu, 'minstock: ', $minstock) ";

			XQPreparedExpression consulta = connection.prepareExpression(squery);
			XQResultSequence resultat = consulta.executeQuery();
			while(resultat.next()){
				System.out.println("Element:"  + resultat.getItemAsString(null));
			}

	}

	public void ej3() throws IOException, XQException{
		connection = ExistConnectionManager.getConnection();

		XQPreparedExpression consulta = null;

		//Preparem consulta
		String squeryCod = "for $cod_zona in data(/zonas/zona/cod_zona) "
				+ "return ($cod_zona)";

		consulta = connection.prepareExpression(squeryCod);
		//Executem la consulta per obtenir el codi
		XQResultSequence resultat = consulta.executeQuery();

		//Un bucle per que es faci per cada codi que tenim en el resultat de la primera consulta
		while(resultat.next()){
			//Anem guardant el codi que ens va pasant
			String codi = resultat.getItemAsString(null);

			//Preparem el nou del archiu segons el codi que obtenim
			String arxiuXML = "ProdZona" + codi + ".xml";
			System.out.println("creado xml " + arxiuXML);
			File fitxer = new File(arxiuXML);


			//Guardem el nom de la zona
			String nom_zona = "let $nom_zona:=/zonas/zona/nombre[../cod_zona = " + codi +"]"
					+ "return $nom_zona ";

			consulta = connection.prepareExpression(nom_zona);
			//Executem la consulta per obtenir el codi
			XQResultSequence resultatNom = consulta.executeQuery();
			String nomZona = "";
			while(resultatNom.next()){
				nomZona = resultatNom.getItemAsString(null);

				String squery = "for $productos in /productos/produc[cod_zona = " + codi + "]"
						+ "let $cod_prod:=$productos/cod_prod "
						+ "let $denominacion:=$productos/denominacion "
						+ "return"
						+ "<producto> "
						+ "	{$cod_prod}"
						+ " {$denominacion}"
						+ "</producto>";

				consulta = connection.prepareExpression(squery);
				//Executem la consulta per obtenir les dades
				XQResultSequence resultatData = consulta.executeQuery();

				BufferedWriter bw = new BufferedWriter(new FileWriter(fitxer));
				bw.write("<?xml version='1.0' encoding='ISO-8859-1' ?>\n");
				bw.write("<prodzona" + codi + ">");
				bw.write(nomZona);
				while(resultatData.next()){
					String element = resultatData.getItemAsString(null);
					bw.write(element);
				}
				bw.write("</prodzona" + codi + ">");
				bw.close();
			}
		}
	}

}
